CREATE TABLE actors_history_scd (
    actor VARCHAR,
    actorid INTEGER,
    quality_class VARCHAR,
    is_active BOOLEAN,
    start_date INTEGER,
    end_date INTEGER,
    current_flag BOOLEAN
);